package coreq;
import java.util.Scanner;

public class UsingMathMethods {
   public static void main(String[] args) {
      Scanner scnr = new Scanner(System.in);
      double x;
      double y;
      double z;
      /* Type your code here. */
   }
}
