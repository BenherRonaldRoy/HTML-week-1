package coreq;

import java.util.Scanner;

public class Cylinder {
   public static void main(String[] args) {
	   
	  /* Type your code here. */
	   
   }
}
