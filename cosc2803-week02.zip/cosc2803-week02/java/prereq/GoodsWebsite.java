package prereq;

public class GoodsWebsite {

   public static void main(String[] args) {
      
      Listing item1 = new Listing();
      Listing item2 = new Listing();
      Listing item3 = new Listing();

      // TODO: Create three listings, setting the properties
      
      // TODO: Output all of the item
   }
}