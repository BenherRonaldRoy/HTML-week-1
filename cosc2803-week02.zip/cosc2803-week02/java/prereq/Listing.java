package prereq;

public class Listing {
   // These are examples properties
   private String title;
   private double price;

   // TODO: Add more properties

   // TODO: Add your setter/getter here
   
   public void printInfo() {
      // TODO: Complete this to print out the information of the Listing
      System.out.println("Item: " + title);
      System.out.println("\tPrice: " + price);
   }
}